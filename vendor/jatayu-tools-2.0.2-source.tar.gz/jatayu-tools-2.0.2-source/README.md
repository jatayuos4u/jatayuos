# Jatayu Tools 2.0.2 preserved package source

This archive preserves every installed file and Debian control file extracted
from the exact jatayu-tools_2.0.2_all.deb used by JatayuOS Build 35. The Python
sources, SVG assets, original PNG icons, notices, user help, AppStream metadata
and launchers are included in payload/. No runtime bytes were edited.

Existing application license: GPL-3.0-or-later; AppStream metadata: CC0-1.0.
Read COPYING and payload/usr/share/doc/jatayu-tools/copyright. Dependencies
retain their own licenses and require their own source/notices as applicable.

Build prerequisites: Python 3 and dpkg-deb. Run:

    python3 build.py /absolute/path/jatayu-tools_2.0.2_all.deb

The build helper was added for source publication; it was not the original
package producer. It reassembles the preserved source payload into a Debian
package. Payload equivalence is tested; bit-for-bit archive reproducibility
or provenance of unavailable historical packaging tools is not claimed.

This archive is only Jatayu Tools source, not the complete ISO source set.
