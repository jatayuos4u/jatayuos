#!/usr/bin/env python3
"""Assemble the preserved Jatayu Tools 2.0.2 source payload with Debian tools."""
from pathlib import Path
import shutil,subprocess,tempfile,sys
root=Path(__file__).resolve().parent
output=Path(sys.argv[1] if len(sys.argv)>1 else 'jatayu-tools_2.0.2_all.deb').resolve()
if output.exists():raise SystemExit('Refusing to overwrite output')
with tempfile.TemporaryDirectory(prefix='jatayu-tools-source-') as tmp:
 stage=Path(tmp)/'package';shutil.copytree(root/'payload',stage)
 subprocess.run(['dpkg-deb','--root-owner-group','--build',str(stage),str(output)],check=True)
print(output)
