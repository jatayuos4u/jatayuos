# Jatayu Tools 2.0 · Creative Studio

**Your files. Your device. Your way.**

An offline image and PDF desktop app for JatayuOS, Debian 13, KDE Plasma and XFCE.

## Image Studio

- Open PNG, JPG/JPEG, WebP, BMP, TIFF and GIF images (first GIF frame).
- Convert to JPG, PNG, WebP, BMP, TIFF or a one-page PDF.
- Compress JPEG and WebP at an adjustable quality; optimize PNG losslessly.
- Resize with optional aspect ratio preservation.
- Merge two or more selected images into one multipage PDF.

## PDF Studio

- Merge two or more selected PDFs into one PDF in queue order.
- Compress a PDF with Screen, Ebook, Printer or Prepress presets.
- Convert PDF pages to separate JPG, PNG, WebP, BMP or TIFF images at selectable resolution.
- Extract a selected range of pages to one PDF; split selected pages into separate PDFs.
- Rotate selected pages in a copy of a PDF by 90, 180 or 270 degrees.

The UI offers local file drop, job selection, status, progress, an inspector, a local output folder, personal settings preset and local processing history. Source files are preserved. Output names receive a numeric suffix when necessary. Queue processing can be stopped between files; an active conversion finishes before cancellation takes effect. Individual merge operations currently run synchronously.

## Installation and ISO integration

Install with `sudo apt install ./jatayu-tools_2.0.0_all.deb`. On an offline ISO, include these Debian 13 dependencies in a local repository: `python3`, `python3-pyqt6`, `python3-pil`, `python3-pypdf`, `poppler-utils`, `ghostscript`. No internet connection, account or telemetry is needed during use. The dependency packages are not embedded in this .deb.

The package includes a freedesktop AppStream metainfo file and a matching desktop entry so software centers can display JatayuOS contributors and GPL-3.0-or-later. A software center's initial screen for a local unindexed .deb may still show unknown author/license depending on its backend; check the installed app entry after refreshing its catalog. The Debian package control file identifies its maintainer as JatayuOS contributors.

## Accuracy and limits

PDF compression can increase size or change PDF features. PDF-to-image removes selectable text from the rendered image. Password-protected PDFs and animated GIF frames after the first are unsupported. JPG has no alpha channel; transparency is composited on white. Color profiles and metadata might not be preserved. PDF merge order follows queue order; check output pages before sharing. No output size estimate is claimed before processing. Image operations have a 180-megapixel safety cap for generated canvases.

## Build and attribution

Run `sh build.sh` from this source directory to create `dist/jatayu-tools_2.0.0_all.deb`. Application source and the bird logo are included in `/usr/share/jatayu-tools/`; legal notices and documentation are in `/usr/share/doc/jatayu-tools/`. The app is GPL-3.0-or-later and the metainfo is CC0-1.0. External Debian packages retain their respective licenses. See `THIRD_PARTY.txt` and `copyright` when redistributing an ISO. No affiliation or endorsement by Debian, KDE or XFCE is implied.
